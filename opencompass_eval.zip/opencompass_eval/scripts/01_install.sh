#!/usr/bin/env bash
# =============================================================================
# OpenCompass 一键环境安装脚本（源码版，含 run.py / tools/list_configs.py / configs）
# 适用：Linux / macOS；仅评测 API 模型时不需要 GPU。
# 用法：
#   bash scripts/01_install.sh
# 可通过环境变量覆盖默认值：
#   PYTHON_BIN=python3.11 OC_DIR=./opencompass bash scripts/01_install.sh
# =============================================================================
set -euo pipefail

# ---------- 可配置项（可用环境变量覆盖）----------
OC_DIR="${OC_DIR:-$HOME/opencompass}"          # OpenCompass 源码存放目录
VENV_DIR="${VENV_DIR:-$HOME/oc_venv}"          # 虚拟环境目录
PYTHON_BIN="${PYTHON_BIN:-python3}"            # 推荐 python3.10 / python3.11
# 数据集来源：ModelScope(国内自动下载，推荐) / HuggingFace(默认)
export DATASET_SOURCE="${DATASET_SOURCE:-ModelScope}"

# 颜色
G() { printf '\033[32m%s\033[0m\n' "$*"; }
Y() { printf '\033[33m%s\033[0m\n' "$*"; }
R() { printf '\033[31m%s\033[0m\n' "$*"; }

G "==> [1/5] 检查 Python 版本（推荐 3.10 / 3.11）"
$PYTHON_BIN --version || { R "未找到 $PYTHON_BIN，请先安装 Python 3.10/3.11 或用 PYTHON_BIN 指定"; exit 1; }

G "==> [2/5] 创建虚拟环境：$VENV_DIR"
if [ ! -d "$VENV_DIR" ]; then
  $PYTHON_BIN -m venv "$VENV_DIR"
fi
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip

G "==> [3/5] 获取 OpenCompass 源码：$OC_DIR"
if [ ! -d "$OC_DIR/.git" ]; then
  # 直连 GitHub 失败时，可改用下面任一镜像取消注释：
  # git clone https://gitee.com/open-compass/opencompass.git "$OC_DIR"
  # git clone https://ghfast.top/https://github.com/open-compass/opencompass.git "$OC_DIR"
  git clone https://github.com/open-compass/opencompass.git "$OC_DIR"
else
  Y "目录已存在，跳过克隆（如需更新：cd $OC_DIR && git pull）"
fi

G "==> [4/5] 安装 OpenCompass 及 API 评测依赖"
cd "$OC_DIR"
# 源码可编辑安装，并带上 api extra（openai / dashscope / volcengine 等）
pip install -e ".[api]"
# 仅 pip 快速安装（不想克隆源码时可用，命令见 README）：
# pip install -U "opencompass[api]"

G "==> [5/5] 写入运行环境文件 $VENV_DIR/oc.env"
cat > "$VENV_DIR/oc.env" <<EOF
# 激活虚拟环境
source $VENV_DIR/bin/activate
# 数据集自动下载源（国内用 ModelScope，可删此行回退 HuggingFace）
export DATASET_SOURCE=$DATASET_SOURCE
# 评测时把下面两项换成你自己的（也可直接 export，详见 env.example）
# export LLM_API_KEY="sk-xxxx"
# export LLM_API_BASE="https://api.deepseek.com"
# export LLM_MODEL_NAME="deepseek-chat"
EOF

G "安装完成！"
Y "下一步："
Y "  1) 编辑  opencompass_eval/env.example 填好 KEY，另存为 ~/.oc_env 并 source"
Y "  2) 执行：source $VENV_DIR/oc.env"
Y "  3) 查看可用数据集：cd $OC_DIR && python tools/list_configs.py gsm8k"
Y "  4) 运行评测：bash opencompass_eval/scripts/run_eval.sh debug"
