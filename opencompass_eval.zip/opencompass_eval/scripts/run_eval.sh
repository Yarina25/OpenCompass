#!/usr/bin/env bash
# =============================================================================
# OpenCompass 运行封装脚本
# 用法：
#   bash scripts/run_eval.sh debug                 # 串行+实时打印，先冒烟测试(默认 demo_gsm8k_chat_gen)
#   bash scripts/run_eval.sh run                   # 正式并行评测
#   bash scripts/run_eval.sh resume                # 复用已完成结果，只补跑失败/未完成任务
#   bash scripts/run_eval.sh viz                   # 不重新推理，只对已有结果重新汇总出表
#   bash scripts/run_eval.sh list gsm8k           # 查询可用数据集/模型配置名（关键字模糊匹配）
#
# 常用环境变量覆盖：
#   OC_DIR=/path/to/opencompass                  # 源码目录（默认 $HOME/opencompass）
#   MODEL_CFG=configs/model_ab_compare.py        # 换模型/对比配置
#   DATASETS="demo_gsm8k_chat_gen"               # 换数据集（空格分隔多个）
#   WORK=outputs/run1                            # 结果输出目录
#   MAX_WORKERS=16                               # 最大并行任务数
# =============================================================================
set -euo pipefail

# 脚本所在目录（opencompass_eval/scripts），据此定位自带 configs
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EVAL_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

OC_DIR="${OC_DIR:-$HOME/opencompass}"
MODEL_CFG="${MODEL_CFG:-$EVAL_ROOT/configs/model_openai_compatible.py}"
DATASETS="${DATASETS:-demo_gsm8k_chat_gen}"
WORK="${WORK:-$EVAL_ROOT/outputs/run1}"
MAX_WORKERS="${MAX_WORKERS:-16}"

G() { printf '\033[32m%s\033[0m\n' "$*"; }
Y() { printf '\033[33m%s\033[0m\n' "$*"; }

cmd="${1:-debug}"

cd "$OC_DIR"
G "OpenCompass 源码目录：$OC_DIR"
G "模型配置：$MODEL_CFG"
G "数据集：$DATASETS"
G "输出目录：$WORK"

case "$cmd" in
  debug)
    # --debug：任务串行执行、实时打印，便于排查鉴权/格式问题
    python run.py --models "$MODEL_CFG" --datasets $DATASETS \
      -w "$WORK" --debug --max-num-workers 1
    ;;
  run)
    python run.py --models "$MODEL_CFG" --datasets $DATASETS \
      -w "$WORK" --max-num-workers "$MAX_WORKERS"
    ;;
  resume)
    # -r 复用 outputs 中已完成的推理结果，仅补跑缺失/失败任务
    python run.py --models "$MODEL_CFG" --datasets $DATASETS \
      -w "$WORK" -r --max-num-workers "$MAX_WORKERS"
    ;;
  viz)
    # 只基于已有 predictions/results 重新汇总，不调用模型
    python run.py --models "$MODEL_CFG" --datasets $DATASETS \
      -w "$WORK" --mode viz
    ;;
  list)
    shift || true
    python tools/list_configs.py "$@"
    ;;
  *)
    Y "未知子命令：$cmd；可用 debug | run | resume | viz | list"
    exit 1
    ;;
esac

G "完成。汇总表见 $WORK/<时间戳>/summary/ ，终端也会打印得分表。"
