# =============================================================================
# 全配置文件模式示例（模型 + 数据集写在一个 py 里，直接传给 run.py）
# 用法：
#   python run.py <本文件路径> -w outputs/demo --debug
#
# 说明：内置数据集的 import 路径/文件名带版本哈希（如 gsm8k_0shot_v2_gen_a58960），
# 会随 OpenCompass 版本变化。首次使用先查真实名字再替换下面 import：
#   python tools/list_configs.py gsm8k
#   python tools/list_configs.py mmlu
#   python tools/list_configs.py ceval
# 不想改 import 时，更简单的方式是用命令行 --datasets（见 run_eval.sh）。
# =============================================================================
import os
from mmengine.config import read_base
from opencompass.models import OpenAISDK

# ---- 数据集继承：按 list_configs.py 查到的真实模块路径替换 ----
with read_base():
    # 示例（路径以你本机 list_configs 输出为准）：
    # from opencompass.configs.datasets.gsm8k.gsm8k_0shot_v2_gen_a58960 import gsm8k_datasets
    # from opencompass.configs.datasets.mmlu.mmlu_gen_a484b3 import mmlu_datasets
    # from opencompass.configs.datasets.ceval.ceval_gen_5f30c7 import ceval_datasets
    pass

# datasets = [*gsm8k_datasets, *mmlu_datasets, *ceval_datasets]  # 取消注释并合并

# ---- 模型（与 model_openai_compatible.py 等价，内联在此）----
models = [
    dict(
        type=OpenAISDK,
        abbr=os.environ.get("LLM_ABBR", "custom-api-model"),
        path=os.environ.get("LLM_MODEL_NAME", "deepseek-chat"),
        key=os.environ.get("LLM_API_KEY", "PUT_YOUR_KEY_HERE"),
        openai_api_base=os.environ.get("LLM_API_BASE", "https://api.deepseek.com"),
        temperature=0.0,
        openai_extra_kwargs=dict(top_p=1.0),
        max_seq_len=32768,
        max_out_len=2048,
        batch_size=8,
        max_workers=8,
        query_per_second=5,
        timeout=600,
        retry=5,
        run_cfg=dict(num_gpus=0),
    )
]
