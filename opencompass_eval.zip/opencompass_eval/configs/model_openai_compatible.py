# =============================================================================
# 自定义 OpenAI 兼容 API 模型配置（OpenAISDK / Chat Completions）
# 通过环境变量注入密钥与服务地址，不在代码里写死 KEY。
#
# 用法（在 opencompass 源码根目录）：
#   python run.py --models <本文件路径> --datasets <数据集名> -w outputs/run1 --debug
# 或用封装脚本：bash scripts/run_eval.sh debug
#
# 支持任何兼容 OpenAI Chat Completions 协议的服务：
#   厂商        openai_api_base                                      path(模型名)
#   ----------  ---------------------------------------------------  ----------------------
#   DeepSeek    https://api.deepseek.com  (或 /v1)                   deepseek-chat / deepseek-reasoner
#   通义千问    https://dashscope.aliyuncs.com/compatible-mode/v1    qwen-turbo / qwen-max / qwen-plus
#   智谱GLM     https://open.bigmodel.cn/api/paas/v4/                glm-4-flash / glm-4-plus
#   OpenAI      https://api.openai.com/v1                            gpt-4o / gpt-4o-mini
#   火山方舟    https://ark.cn-beijing.volces.com/api/v3             ep-xxxxxxxx (接入点ID)
#   Ollama本地  http://localhost:11434/v1                            qwen:7b (key 任意填)
# =============================================================================
import os
from opencompass.models import OpenAISDK

# 从环境变量读取；未设置时给出占位，便于提前发现漏配
API_KEY = os.environ.get("LLM_API_KEY", "PUT_YOUR_KEY_HERE")
API_BASE = os.environ.get("LLM_API_BASE", "https://api.deepseek.com")
MODEL_NAME = os.environ.get("LLM_MODEL_NAME", "deepseek-chat")
ABBR = os.environ.get("LLM_ABBR", "custom-api-model")

models = [
    dict(
        type=OpenAISDK,
        abbr=ABBR,                       # 结果表/输出目录里显示的简称
        path=MODEL_NAME,                 # 服务端模型名 / 接入点ID
        key=API_KEY,
        openai_api_base=API_BASE,
        # tokenizer_path="Qwen/Qwen2.5-7B-Instruct",  # 网关/自定义模型名估算长度时再填

        # ---- 采样：评测建议固定 temperature=0，保证可复现 ----
        temperature=0.0,
        openai_extra_kwargs=dict(top_p=1.0),

        # ---- 长度 ----
        max_seq_len=32768,               # 输入+输出上限，按模型实际窗口改
        max_out_len=2048,                # 单次最大生成 token

        # ---- 并发 / 限流 / 容错（API 模型不占 GPU）----
        batch_size=8,                    # OpenICLInferTask 下约等于并发线程数
        max_workers=8,                   # 最大并发线程
        query_per_second=5,              # 每秒请求上限，防 429 限流；额度低就调小
        timeout=600,                    # 单请求超时(秒)
        retry=5,                         # 失败重试次数
        run_cfg=dict(num_gpus=0),        # API 模型不需要 GPU
    )
]
