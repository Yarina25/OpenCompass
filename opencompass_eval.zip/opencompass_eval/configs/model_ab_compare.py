# =============================================================================
# A/B 双模型对比配置示例：同时评测两个 OpenAI 兼容 API，结果并排输出到汇总表。
# 模型A 读 LLM_A_*，模型B 读 LLM_B_*；未设置的项回退到通用 LLM_*。
#
# 用法：
#   python run.py --models <本文件路径> --datasets <数据集名> -w outputs/ab --debug
# =============================================================================
import os
from opencompass.models import OpenAISDK


def _mk(prefix: str, default_abbr: str) -> dict:
    return dict(
        type=OpenAISDK,
        abbr=os.environ.get(f"{prefix}_ABBR", default_abbr),
        path=os.environ.get(f"{prefix}_MODEL_NAME", os.environ.get("LLM_MODEL_NAME", "deepseek-chat")),
        key=os.environ.get(f"{prefix}_API_KEY", os.environ.get("LLM_API_KEY", "PUT_YOUR_KEY_HERE")),
        openai_api_base=os.environ.get(f"{prefix}_API_BASE", os.environ.get("LLM_API_BASE", "https://api.deepseek.com")),
        temperature=0.0,
        openai_extra_kwargs=dict(top_p=1.0),
        max_seq_len=32768,
        max_out_len=2048,
        batch_size=8,
        max_workers=8,
        query_per_second=5,
        timeout=600,
        retry=5,
        run_cfg=dict(num_gpus=0),
    )


models = [
    _mk("LLM_A", "model-A"),
    _mk("LLM_B", "model-B"),
]
